create view alleselskaper
            (navn, uuid, orgnr, konkursflagg, likvidasjonflagg, nacekode, organisasjonstype, oppløstdato,
             etablertdato) as
SELECT selskap.navn,
       selskap.uuid,
       selskap.orgnr,
       selskap.konkursflagg,
       selskap.likvidasjonflagg,
       selskap.nacekode,
       selskap.organisasjonstype,
       selskap."oppløstdato",
       selskap.etablertdato
FROM selskap
UNION ALL
SELECT konkurs.navn,
       konkurs.uuid,
       konkurs.orgnr,
       konkurs.konkursflagg,
       konkurs.likvidasjonflagg,
       konkurs.nacekode,
       konkurs.organisasjonstype,
       konkurs."oppløstdato",
       konkurs.etablertdato
FROM konkurs;

alter table alleselskaper
    owner to mgwrenst;

